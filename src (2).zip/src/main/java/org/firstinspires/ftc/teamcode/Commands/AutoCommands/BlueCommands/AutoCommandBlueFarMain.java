package org.firstinspires.ftc.teamcode.Commands.AutoCommands.BlueCommands;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;

import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.DriveToPosePathFocus;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.DriveToPosePathPid;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.FollowPathAuto;
import org.firstinspires.ftc.teamcode.Constants.DrivetrainConstants;
import org.firstinspires.ftc.teamcode.Positions.BluePositions;
import org.firstinspires.ftc.teamcode.Subsystems.DrivetrainSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.TheMachineSubsystem;

public class AutoCommandBlueFarMain extends SequentialCommandGroup {

    private final TheMachineSubsystem theMachineSubsystem;
    private final DrivetrainSubsystem drivetrain;

    private Command driveAndShootP4;
    private Command driveAndShootP1_2;
    private Command driveAndShootP1_3;
    private Command driveAndShootP1_4;

    public AutoCommandBlueFarMain(TheMachineSubsystem theMachineSubsystem, DrivetrainSubsystem drivetrain) {
        this.theMachineSubsystem = theMachineSubsystem;
        this.drivetrain = drivetrain;

        driveAndShootP4 = new DriveToPosePathFocus(drivetrain,BluePositions.SHOOT_P4_2).alongWith(theMachineSubsystem.prepP4Request()).withTimeout(DrivetrainConstants.AimTimeOut*2)
                .andThen(theMachineSubsystem
                    .shootFromP4Request());
        AutoCommandBlueFarMain.Paths paths = new AutoCommandBlueFarMain.Paths(drivetrain.getFollower());

        addCommands(
                new DriveToPosePathPid(drivetrain, BluePositions.SHOOT_P4_2),
                driveAndShootP4,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(drivetrain,paths.Intake1_1),
                new FollowPathAuto(drivetrain,paths.Intake1_2),
                driveAndShootP4,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(drivetrain,paths.Intake2_1),
                new FollowPathAuto(drivetrain,paths.Intake2_2),
                driveAndShootP4
        );

    }
    public static class Paths {
        public PathChain Intake1_1;
        public PathChain Intake1_2;
        public PathChain Intake2_1;
        public PathChain Intake2_2;

        public Paths(Follower follower) {
            Intake1_1 = follower.pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    new Pose(57.000, 20.000),
                                    new Pose(75.722, 27.825),
                                    new Pose(62.114, 30)
                            )
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(111.44), Math.toRadians(0))
                    .build();

            Intake1_2 = follower.pathBuilder()
                    .addPath(
                            new BezierLine(
                                    new Pose(62.114, 30),
                                    new Pose(10.318, 35.500)
                            )
                    )
                    .setTangentHeadingInterpolation()
                    .setReversed()
                    .build();
            Intake2_1 = follower.pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    new Pose(57.000, 20.000),
                                    new Pose(75.722, 27.825),
                                    new Pose(62.114, 58.000)
                            )
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(111.44), Math.toRadians(0))
                    .build();

            Intake2_2 = follower.pathBuilder()
                    .addPath(
                            new BezierLine(
                                    new Pose(62.114, 58.000),
                                    new Pose(10.318, 58.000)
                            )
                    )
                    .setTangentHeadingInterpolation()
                    .setReversed()
                    .build();
        }

    }
}
