package org.firstinspires.ftc.teamcode.Commands.AutoCommands.RedCommands;

import static org.firstinspires.ftc.teamcode.Commands.AutoCommands.Utilities.MirrorCalculator.mirrorPose;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.arcrobotics.ftclib.command.WaitCommand;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;

import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.DriveToShootP5;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.DriveToShootP5AUTO;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.FollowPathAuto;
import org.firstinspires.ftc.teamcode.Constants.DrivetrainConstants;
import org.firstinspires.ftc.teamcode.Container;
import org.firstinspires.ftc.teamcode.Subsystems.DrivetrainSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.TheMachineSubsystem;

public class AutoRedCommandRoman extends SequentialCommandGroup {
    private final TheMachineSubsystem m_machine;
    private final DrivetrainSubsystem m_drive;

    private Command driveAndShootP5_1;
    private Command driveAndShootP5_2;
    private Command driveAndShootP5_3;
    private Command driveAndShootP1_4;

    public AutoRedCommandRoman(TheMachineSubsystem theMachineSubsystem, DrivetrainSubsystem drivetrain) {
        this.m_machine = theMachineSubsystem;
        this.m_drive = drivetrain;

        AutoRedCommandRoman.Paths paths = new AutoRedCommandRoman.Paths(drivetrain.getFollower());


        driveAndShootP5_1 = new DriveToShootP5AUTO(drivetrain).alongWith(m_machine.prepP5Request()).withTimeout(DrivetrainConstants.AimTimeOut*2)
                .andThen(m_machine
                        .shootFromPoseRequest());
        driveAndShootP5_2 = new DriveToShootP5AUTO(drivetrain).alongWith(m_machine.prepP5Request()).withTimeout(DrivetrainConstants.AimTimeOut)
                .andThen(m_machine
                        .shootFromPoseRequest());
        driveAndShootP5_3 = new DriveToShootP5AUTO(drivetrain).alongWith(m_machine.prepP5Request()).withTimeout(DrivetrainConstants.AimTimeOut)
                .andThen(m_machine.shootFromPoseRequest());
        addCommands(
                new InstantCommand(()->{
                    Container.autoPrep1 = true;
                }),
                driveAndShootP5_1,
                theMachineSubsystem.waitForFeederToFeed(),
                new InstantCommand(()->{
                    Container.autoPrep1 = false;
                }),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(drivetrain,paths.Intake1),
                new WaitCommand(250),
                driveAndShootP5_2,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(m_drive, paths.IntakeLever),
                new WaitCommand(800),
                m_machine.prepP5Request(),
                new FollowPathAuto(m_drive,paths.ReturnShoot1),
                driveAndShootP5_2,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(m_drive, paths.IntakeLever),
                new WaitCommand(800),
                m_machine.prepP5Request(),
                new FollowPathAuto(m_drive,paths.ReturnShoot1),
                driveAndShootP5_2,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(m_drive, paths.IntakeLever),
                new WaitCommand(800),
                m_machine.prepP5Request(),
                new FollowPathAuto(m_drive,paths.ReturnShoot1),
                driveAndShootP5_2
        );
    }

    public static class Paths {
        public PathChain Intake1;
        public PathChain IntakeLever;
        public PathChain ReturnShoot1;

        public Paths(Follower follower) {
            Intake1 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    mirrorPose(new Pose(54.800, 82.000, Math.toRadians(130))),
                                    mirrorPose(new Pose(49.509, 91.019, 0)), // Heading doesn't matter for control points
                                    mirrorPose(new Pose(20.226, 56.453, Math.toRadians(30)))
                            )
                    )
                    // We extract the headings from the mirrored Poses to keep the interpolation correct
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(130))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(30))).getHeading()
                    )
                    .build();

            IntakeLever = follower.pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    mirrorPose(new Pose(54.613, 82.000)),
                                    mirrorPose(new Pose(38.910, 33.735)),
                                    mirrorPose(new Pose(12, 62.2))
                            )
                    )
                    .setTangentHeadingInterpolation()
                    .setReversed()
                    .build();

            ReturnShoot1 = follower.pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    mirrorPose(new Pose(12, 62.2)),
                                    mirrorPose(new Pose(38.910, 33.735)),
                                    mirrorPose(new Pose(54.613, 82.000))
                            )
                    )
                    .setTangentHeadingInterpolation()
                    .build();
        }
    }
}
