package org.firstinspires.ftc.teamcode.Commands.AutoCommands.RedCommands;

import static org.firstinspires.ftc.teamcode.Commands.AutoCommands.Utilities.MirrorCalculator.mirrorPose;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.arcrobotics.ftclib.command.WaitCommand;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;

import org.firstinspires.ftc.teamcode.Commands.AutoCommands.Utilities.FitFitCommand;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.AimToFocus;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.DriveToShootP5;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.DriveToShootP5AUTO;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.FollowPathAuto;
import org.firstinspires.ftc.teamcode.Constants.DrivetrainConstants;
import org.firstinspires.ftc.teamcode.Constants.TheMachineConstants;
import org.firstinspires.ftc.teamcode.Container;
import org.firstinspires.ftc.teamcode.Subsystems.DrivetrainSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.TheMachineSubsystem;

public class MainAutoCommandRedFarCloseShoot extends SequentialCommandGroup {

    private final TheMachineSubsystem theMachineSubsystem;
    private final DrivetrainSubsystem drivetrain;

    private Command driveAndShootP1_1;
    private Command driveAndShootP1_2;
    private Command driveAndShootP1_3;
    private Command driveAndShootP1_4;

    public MainAutoCommandRedFarCloseShoot(TheMachineSubsystem theMachineSubsystem, DrivetrainSubsystem drivetrain) {
        this.theMachineSubsystem = theMachineSubsystem;
        this.drivetrain = drivetrain;

        Paths paths = new Paths(drivetrain.getFollower());


        driveAndShootP1_1 = new DriveToShootP5AUTO(drivetrain).alongWith(theMachineSubsystem.prepP5Request()).withTimeout(DrivetrainConstants.AimTimeOutAutoFirst)
                .andThen(theMachineSubsystem
                        .shootFromPoseRequest());
        driveAndShootP1_2 = new DriveToShootP5AUTO(drivetrain).alongWith(theMachineSubsystem.getIntakeSubsystem().intakeRequest().andThen(new WaitCommand(700)).andThen(new FitFitCommand(theMachineSubsystem,drivetrain))).alongWith(new WaitCommand(500).andThen(theMachineSubsystem.prepP5Request())).withTimeout(DrivetrainConstants.AimTimeOut)
                .andThen(theMachineSubsystem
                        .shootFromPoseRequest().alongWith(new AimToFocus(drivetrain).withTimeout(900)));
        driveAndShootP1_3 = new DriveToShootP5AUTO(drivetrain).alongWith(theMachineSubsystem.getIntakeSubsystem().intakeRequest().andThen(new WaitCommand(700)).andThen(new FitFitCommand(theMachineSubsystem,drivetrain))).alongWith(new WaitCommand(500).andThen(theMachineSubsystem.prepP5Request())).withTimeout(DrivetrainConstants.AimTimeOut)
                .andThen(theMachineSubsystem
                        .shootFromPoseRequest().alongWith(new AimToFocus(drivetrain).withTimeout(900)));
        driveAndShootP1_4 = new DriveToShootP5AUTO(drivetrain).alongWith(theMachineSubsystem.getIntakeSubsystem().intakeRequest().andThen(new WaitCommand(700)).andThen(new FitFitCommand(theMachineSubsystem,drivetrain))).alongWith(new WaitCommand(500).andThen(theMachineSubsystem.prepP5Request())).withTimeout(DrivetrainConstants.AimTimeOut)
                //.andThen(new DriveToPosePID(drivetrain, BluePositions.SHOOT_P5))
                .withTimeout(DrivetrainConstants.AimTimeOut*2)
                .andThen(theMachineSubsystem.shootFromPoseRequest().alongWith(new AimToFocus(drivetrain).withTimeout(900)));

        addCommands(
                new InstantCommand(()->{
                    Container.autoPrep1 = true;
                }),
                driveAndShootP1_1,
                new InstantCommand(()->{
                    Container.autoPrep1 = false;
                }),
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(drivetrain,paths.Intake1),
                new WaitCommand(200),
                driveAndShootP1_2,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(drivetrain,paths.Intake2),
                new WaitCommand(200),
                driveAndShootP1_3,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(drivetrain,paths.Intake3),
                new WaitCommand(200),
                driveAndShootP1_4
        );
    }

    public static class Paths {

        public PathChain Shoot1, Shoot2, Shoot3, Shoot4;
        public PathChain Intake1, Intake2, Intake3, Lever;

        public Paths(Follower follower) {
            Shoot1 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            mirrorPose(new Pose(61.335, 11.318)),
                            mirrorPose(new Pose(62.943, 58.415)),
                            mirrorPose(new Pose(54.800, 82.000))
                    ))
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(90))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(130))).getHeading()
                    )
                    .setTimeoutConstraint(TheMachineConstants.shootTimeoutConstraint)
                    .build();

            Intake1 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            mirrorPose(new Pose(54.800, 82.000)),
                            mirrorPose(new Pose(57.358, 117.434)),
                            mirrorPose(new Pose(22.642, 86.038))
                    ))
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(130))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(40))).getHeading()
                    )
                    .build();

            Lever = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            mirrorPose(new Pose(22.642, 86.038)),
                            mirrorPose(new Pose(42.566, 83.472)),
                            mirrorPose(new Pose(15.396, 79.094))
                    ))
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(40))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(90))).getHeading()
                    )
                    .setTimeoutConstraint(0)
                    .setTValueConstraint(0.8)
                    .build();

            Shoot2 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            mirrorPose(new Pose(15.396, 79.094)),
                            mirrorPose(new Pose(47.094, 73.811)),
                            mirrorPose(new Pose(54.800, 82.000))
                    ))
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(90))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(130))).getHeading()
                    )
                    .setTimeoutConstraint(TheMachineConstants.shootTimeoutConstraint)
                    .build();

            Intake2 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            mirrorPose(new Pose(54.800, 82.000)),
                            mirrorPose(new Pose(49.509, 91.019)),
                            mirrorPose(new Pose(20.226, 56.453))
                    ))
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(130))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(30))).getHeading()
                    )
                    .build();

            Shoot3 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            mirrorPose(new Pose(20.226, 56.453)),
                            mirrorPose(new Pose(49.358, 65.057)),
                            mirrorPose(new Pose(54.800, 82.000))
                    ))
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(30))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(130))).getHeading()
                    )
                    .setTimeoutConstraint(TheMachineConstants.shootTimeoutConstraint)
                    .build();

            Intake3 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            mirrorPose(new Pose(54.800, 82.000)),
                            mirrorPose(new Pose(57.509, 54.189)),
                            mirrorPose(new Pose(18.113, 36))
                    ))
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(130))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(30))).getHeading()
                    )
                    .build();

            Shoot4 = follower.pathBuilder()
                    .addPath(new BezierCurve(
                            mirrorPose(new Pose(18.113, 34.113)),
                            mirrorPose(new Pose(32.302, 11.925)),
                            mirrorPose(new Pose(54.340, 16.151))
                    ))
                    .setLinearHeadingInterpolation(
                            mirrorPose(new Pose(0, 0, Math.toRadians(30))).getHeading(),
                            mirrorPose(new Pose(0, 0, Math.toRadians(110.5))).getHeading()
                    )
                    .setTimeoutConstraint(TheMachineConstants.shootTimeoutConstraint)
                    .build();
        }
    }
}
