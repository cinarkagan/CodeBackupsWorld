package org.firstinspires.ftc.teamcode.Commands.AutoCommands.Utilities;

import com.pedropathing.geometry.Pose;

public class MirrorCalculator {
    public static Pose mirrorPose(Pose p) {
        double mirroredHeading = Math.PI - p.getHeading();

        // Normalize heading to stay within [-pi, pi]
        while (mirroredHeading > Math.PI) mirroredHeading -= 2 * Math.PI;
        while (mirroredHeading < -Math.PI) mirroredHeading += 2 * Math.PI;

        return new Pose(141 - p.getX(), p.getY(), mirroredHeading);
    }
}
