package org.firstinspires.ftc.teamcode.Commands.StateActions.FunnelActions;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.Constants.FunnelConstants;
import org.firstinspires.ftc.teamcode.Constants.ShooterConstants;
import org.firstinspires.ftc.teamcode.Container;
import org.firstinspires.ftc.teamcode.Subsystems.FunnelSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.Utils.AllStates;

/**
 * Action command to move the funnel servos to the FEED position.
 * This action implements a delayed sequence for servo movement.
 */
public class FunnelFeedActionBetter extends CommandBase
{

    private final FunnelSubsystem funnelSubsystem;
    private final ShooterSubsystem shooterSubsystem;

    private double shootCounter = 0;
    private long now;
    private long startTimeFor2;
    private boolean setStartTime;
    /**
     * Constructor for FunnelFeedAction.
     * @param funnelSubsystem The funnel subsystem instance.
     */
    public FunnelFeedActionBetter(FunnelSubsystem funnelSubsystem, ShooterSubsystem shooterSubsystem)
    {
        addRequirements(funnelSubsystem);
        this.funnelSubsystem = funnelSubsystem;
        this.shooterSubsystem = shooterSubsystem;


        funnelSubsystem.setFunnelFeedOrderByColor();


    }

    @Override
    public void initialize() {
        shootCounter = 0;
        startTimeFor2 = 0;
        setStartTime = false;
        now = 0;
    }

    @Override
    public void execute()
    {
        now = System.currentTimeMillis();
        if (shooterSubsystem.checkRPMRawRight(shooterSubsystem.getGoalRPM()))
        {if (!funnelSubsystem.checkIsFeedBetterR()) {
            funnelSubsystem.setRightServoFeed();
            shootCounter++;
        }}
        if (shooterSubsystem.checkRPMRawMiddle(shooterSubsystem.getGoalRPM()))
        {if (!funnelSubsystem.checkIsFeedBetterM()) {
            funnelSubsystem.setMiddleServoFeed();
            shootCounter++;
        }}
        if (shooterSubsystem.checkRPMRawLeft(shooterSubsystem.getGoalRPM()))
        {if (!funnelSubsystem.checkIsFeedBetterL()) {
            funnelSubsystem.setLeftServoFeed();
            shootCounter++;
        }}
        if (shootCounter==2&&(!setStartTime)){
            startTimeFor2 = now;
            setStartTime = true;
        }
        if (Container.isTeleop){
        if ((Math.abs(now-startTimeFor2)>=FunnelConstants.FeedDelayInstaShoot)&&setStartTime){
            if (!funnelSubsystem.checkIsFeedBetterL()) {
                funnelSubsystem.setLeftServoFeed();
                shootCounter++;
            }
            if (!funnelSubsystem.checkIsFeedBetterM()) {
                funnelSubsystem.setMiddleServoFeed();
                shootCounter++;
            }
            if (!funnelSubsystem.checkIsFeedBetterR()) {
                funnelSubsystem.setRightServoFeed();
                shootCounter++;
            }
        }} else if ((Math.abs(now-startTimeFor2)>=FunnelConstants.FeedDelayInstaShootAuto)&&setStartTime){
            if (!funnelSubsystem.checkIsFeedBetterL()) {
                funnelSubsystem.setLeftServoFeed();
                shootCounter++;
            }
            if (!funnelSubsystem.checkIsFeedBetterM()) {
                funnelSubsystem.setMiddleServoFeed();
                shootCounter++;
            }
            if (!funnelSubsystem.checkIsFeedBetterR()) {
                funnelSubsystem.setRightServoFeed();
                shootCounter++;
            }
        }
    }

    private boolean checkFinish()
    {
        return funnelSubsystem.getState() != AllStates.FunnelStates.FEED;
    }

    /**
     * Checks if the action is finished.
     * @return true if the subsystem state is no longer FEED, false otherwise.
     */
    @Override
    public boolean isFinished()
    {
        return checkFinish();
    }
}
