package org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions;

import com.arcrobotics.ftclib.command.CommandBase;
import org.firstinspires.ftc.teamcode.Utils.AllStates;
import org.firstinspires.ftc.teamcode.Subsystems.ShooterSubsystem;

public class ShooterPrepP3Action extends CommandBase {
    private final ShooterSubsystem shooterSubsystem;

    public ShooterPrepP3Action(ShooterSubsystem shooterSubsystem) {
        this.shooterSubsystem = shooterSubsystem;
        addRequirements(shooterSubsystem);
    }

    @Override
    public void initialize() {
        shooterSubsystem.prepP3();
    }

    @Override
    public void execute() {
        shooterSubsystem.prepP3();
    }

    @Override
    public boolean isFinished() {
        return shooterSubsystem.getState() != AllStates.ShooterStates.PREP_P3;
    }
}