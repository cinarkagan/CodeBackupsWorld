package org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.Subsystems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.Utils.AllStates;

public class ShooterPrepP6Action extends CommandBase {
    private final ShooterSubsystem shooterSubsystem;

    public ShooterPrepP6Action(ShooterSubsystem shooterSubsystem) {
        this.shooterSubsystem = shooterSubsystem;
        addRequirements(shooterSubsystem);
    }

    @Override
    public void initialize() {
        shooterSubsystem.prepP6();
    }

    @Override
    public void execute() {
        shooterSubsystem.prepP6();
    }

    @Override
    public boolean isFinished() {
        return shooterSubsystem.getState() != AllStates.ShooterStates.PREP_P5;
    }
}