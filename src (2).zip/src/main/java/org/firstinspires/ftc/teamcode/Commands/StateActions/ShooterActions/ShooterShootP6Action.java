package org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions;

import com.arcrobotics.ftclib.command.CommandBase;

import org.firstinspires.ftc.teamcode.Subsystems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.Utils.AllStates;

public class ShooterShootP6Action extends CommandBase {
    private final ShooterSubsystem shooterSubsystem;

    public ShooterShootP6Action(ShooterSubsystem shooterSubsystem) {
        addRequirements(shooterSubsystem);
        this.shooterSubsystem = shooterSubsystem;
    }

    @Override
    public void initialize() {
        shooterSubsystem.shootP6();
    }

    @Override
    public void execute() {
        shooterSubsystem.shootP6();
    }

    private boolean checkFinish()
    {
        return shooterSubsystem.getState() != AllStates.ShooterStates.SHOOT_P4;
    }

    @Override
    public boolean isFinished() {
        return checkFinish();
    }
}
