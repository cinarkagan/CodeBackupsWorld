package org.firstinspires.ftc.teamcode;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.InstantCommand;
import com.bylazar.configurables.annotations.Configurable;
import com.pedropathing.geometry.Pose;

import org.firstinspires.ftc.teamcode.Positions.BluePositions;
import org.firstinspires.ftc.teamcode.Positions.RedPositions;
import org.firstinspires.ftc.teamcode.Utils.AllStates;

import java.util.List;

/**
 * Container class to hold global variables and states for the robot.
 * This class acts as a central repository for shared data.
 */
public class Container
{
    /**
     * Flag to indicate if the robot is on the Blue alliance.
     * Default is true.
     */

    public static AllStates.ShooterStates shooterState = AllStates.ShooterStates.REST;

    public static boolean isBlue = true;

    public static boolean isTeleop = true;

    /**
     * Current shooting combination
     * Updated by the LimelightHandler.
     */
    public static String colorCombination = "x";

    public static double headingRadians = 0;

    /**
     * Current pose of the robot on the field.
     * Updated by the DrivetrainSubsystem.
     */
    public static Pose robotPose = (isBlue ? BluePositions.START_POSE : RedPositions.START_POSE);


    /**
     * The pose of the robot at the end of the autonomous period.
     * Used to transfer pose to TeleOp.
     */
    public static Pose autoEndPose = null;

    public static boolean ShouldIShout = false;
    public static boolean autoPrep1 = false;
    public static boolean rearAuto = false;
    public static boolean farShootAuto = false;

    public static Command ShoutTriggerComand()
    {
        return new InstantCommand(() -> {ShouldIShout = !ShouldIShout;});
    }

    public static boolean shootPattern = false;

    public static Command PatternTriggerCommand() {
        return  new InstantCommand(() -> {shootPattern = !shootPattern;});
    }

}
