package org.firstinspires.ftc.teamcode.OpModes.Autonomous.OLD;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.CommandOpMode;
import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.RunCommand;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.arcrobotics.ftclib.command.WaitCommand;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;

import org.firstinspires.ftc.teamcode.Commands.AutoCommands.OLD.MainAutoCommandRedOLD;
//import org.firstinspires.ftc.teamcode.Commands.AutoCommands.UpdatePoseCommand;
import org.firstinspires.ftc.teamcode.Container;
import org.firstinspires.ftc.teamcode.Subsystems.DrivetrainSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.TheMachineSubsystem;
import org.firstinspires.ftc.teamcode.Utils.AllStates;
import org.firstinspires.ftc.teamcode.Utils.Mouth;
@Disabled
@Autonomous(name = "AUTO-Red")
public class    AutoRed extends CommandOpMode {
    private TheMachineSubsystem m_machine;
    private DrivetrainSubsystem m_drive;
    private Mouth mouth;
    public Command initOpCommand;

    public Command periodicOpCommand;
    public SequentialCommandGroup autoCommand;

    @Override
    public void initialize()
    {
        Container.isBlue = false;
        Container.isTeleop = false;
        Container.colorCombination = "x";

        m_drive = new DrivetrainSubsystem(hardwareMap);
        m_machine = new TheMachineSubsystem(hardwareMap, m_drive::getPose);
        mouth = new Mouth(m_machine,m_drive, telemetry);
        m_drive.setTelemetry(mouth.getJoinedTelemetry());

        initOpCommand = new InstantCommand(() -> {
            m_machine.funnelRequest(AllStates.FunnelStates.HOME);
        });

        periodicOpCommand = new RunCommand(() -> {
            //mouth.speak();
            //new UpdatePoseCommand(m_drive);
        });

        autoCommand = new MainAutoCommandRedOLD(m_machine,m_drive);

        schedule(
                initOpCommand.andThen(periodicOpCommand),
                m_machine.idleRequest().andThen(new WaitCommand(500).andThen(autoCommand))
        );
    }


}

