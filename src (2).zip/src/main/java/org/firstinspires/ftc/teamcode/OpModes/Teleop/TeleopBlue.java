package org.firstinspires.ftc.teamcode.OpModes.Teleop;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

@TeleOp(name = "TeleopBlue")
public class TeleopBlue extends TeleopBase {
    public TeleopBlue() {
        super(true); // Passes isBlue = true to the base class
    }
}