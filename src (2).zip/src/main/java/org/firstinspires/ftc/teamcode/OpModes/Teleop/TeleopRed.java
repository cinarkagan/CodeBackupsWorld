package org.firstinspires.ftc.teamcode.OpModes.Teleop;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

@TeleOp(name = "TeleopRed", group = "Competition")
public class TeleopRed extends TeleopBase {
    public TeleopRed() {
        super(false); // Passes isBlue = false to the base class
    }
}