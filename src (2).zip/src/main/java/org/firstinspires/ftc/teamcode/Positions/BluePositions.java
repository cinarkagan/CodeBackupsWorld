    package org.firstinspires.ftc.teamcode.Positions;

    import com.bylazar.configurables.annotations.Configurable;
    import com.pedropathing.geometry.Pose;


    //@Configurable
    public class BluePositions {
        public static double DRIVETRAIN_LENGTH = 13.267;
        public static double rearAngle = Math.toRadians(35);
        public static double rearAngle1 = Math.toRadians(45);

        public static double P5_OFFSET_INCH = 11.8;
        public static Pose START_POSE = new Pose(61.335,11.318,Math.toRadians(90)); //11.318 y start pose ama mert rollendi //new Pose(63.437,11.28,Math.toRadians(90));
        public static Pose START_POSE_REAR = new Pose(13.8+(Math.sin(rearAngle)*DRIVETRAIN_LENGTH/2),127.7-(Math.cos(rearAngle)*DRIVETRAIN_LENGTH/2),Math.toRadians(145)); //11.318 y start pose ama mert rollendi //new Pose(63.437,11.28,Math.toRadians(90));

        public static Pose ZERO_POSE = new Pose((144-(0.5+17.126)),11.318,Math.toRadians(90));  //new Pose(63.437,11.28,Math.toRadians(90));

        public static Pose SHOOT_FOCUS_POINT = new Pose(10,135);
        public static Pose SHOOT_P1 = new Pose(47.7, 95.3, 2.3387412 ); // 2.31 is in radians 2.22
        public static Pose SHOOT_P2 = new Pose(63, 130, 3.09); // 3.15 old
        public static Pose SHOOT_P3 = new Pose(80, 88, Math.toRadians(145));
        public static Pose SHOOT_P4 = new Pose(55, 14, 1.945);

        public static Pose SHOOT_P4_2 = new Pose(57, 20, 1.945);

        public static Pose SHOOT_P5 = new Pose(54.8, 82, Math.toRadians(133));
        public static Pose SHOOT_P5_AUTO = new Pose(54.8-(Math.cos(rearAngle1)*P5_OFFSET_INCH), 82+(Math.sin(rearAngle1)*P5_OFFSET_INCH), Math.toRadians(133));
        public static Pose SHOOT_P6 = new Pose(101, 106, 2.1166582107543945);

        public static Pose SHOOT_TEST = new Pose(60, 84);
        public static Pose SHOOT_TEST_FOCUS_POINT = new Pose(8,133);

        public static Pose FOCUS_POINT = new Pose(7.377,133.292);


    }

