package org.firstinspires.ftc.teamcode.Subsystems;


import androidx.annotation.NonNull;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.SubsystemBase;
import com.arcrobotics.ftclib.command.WaitUntilCommand;
import com.arcrobotics.ftclib.controller.PIDController;
import com.arcrobotics.ftclib.util.MathUtils;
import com.pedropathing.geometry.Pose;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.VoltageSensor;

import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterPrepP1Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterPrepP2Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterPrepP3Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterPrepP4Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterPrepP5Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterPrepP6Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterRestAction;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterReverseAction;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterShakeAction;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterShootFromPoseAction;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterShootP1Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterShootP2Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterShootP3Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterShootP4Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterShootP5Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterShootP6Action;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterTestAction;
import org.firstinspires.ftc.teamcode.Commands.StateActions.ShooterActions.ShooterZeroAction;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterPrepP1Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterPrepP2Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterPrepP3Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterPrepP4Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterPrepP5Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterPrepP6Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterRestRequest;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterReverseRequest;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterShakeRequest;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterShootFromPoseRequest;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterShootP1Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterShootP2Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterShootP3Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterShootP4Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterShootP5Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterShootP6Request;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterTestRequest;
import org.firstinspires.ftc.teamcode.Commands.StateRequests.ShooterRequests.ShooterZeroRequest;
import org.firstinspires.ftc.teamcode.Utils.AllStates.ShooterStates;
import org.firstinspires.ftc.teamcode.Constants.ShooterConstants;
import org.firstinspires.ftc.teamcode.Container;
import org.firstinspires.ftc.teamcode.Positions.BluePositions;
import org.firstinspires.ftc.teamcode.Positions.RedPositions;
import org.firstinspires.ftc.teamcode.Utils.ShooterPIDFController;

import java.sql.Time;
import java.util.EnumSet;
import java.util.Set;
import java.util.function.Supplier;

/**
 * Subsystem responsible for the shooter mechanism.
 * Controls flywheel motors and hood servo to shoot rings/game elements.
 *
 *
 * P1: closest
 * P2: up against wall position
 * P3: near the line corner
 * P4: furthest
 *
 */
public class ShooterSubsystem extends SubsystemBase {

    private final DcMotorEx leftMotor;
    private final DcMotorEx rightMotor;
    private final DcMotorEx middleMotor;
    private final Servo hoodServo;

    private final ShooterPIDFController leftPID;
    private final ShooterPIDFController middlePID;
    private final ShooterPIDFController rightPID;
    private final ShooterPIDFController leftPIDClose;
    private final ShooterPIDFController middlePIDClose;
    private final ShooterPIDFController rightPIDClose;

    private final Supplier<Pose> poseSupplier;

    private double restRpm;
    private final double p1Rpm;
    private final double p2Rpm;
    private final double p3Rpm;
    private final double p4Rpm;

    private final double p1Hood;
    private final double p2Hood;
    private final double p3Hood;
    private final double p4Hood;

    private final Pose p1Pose;
    private final Pose p2Pose;
    private final Pose p3Pose;
    private final Pose p4Pose;

    private final Pose focusPoint;

    private double goalRPM;
    private double goalHood;
    private double prevLOutput;
    private double prevMOutput;
    private double prevROutput;

    private double prevLRPM;
    private double prevLPos;
    private double prevLPosTime;
    private double prevMRPM;
    private double prevMPos;
    private double prevRRPM;
    private double prevRPos;
    private double prevRPosTime;


    private boolean checkedRPMOnce = false;

    private boolean isReady;

    private ShooterStates currentState;
    private ShooterStates lastState;

    private final Command zeroAction;
    private final Command restAction;
    private final Command shootP1Action;
    private final Command shootP2Action;
    private final Command shootP3Action;
    private final Command shootP4Action;
    private final Command shootP5Action;
    private final Command shootP6Action;
    private final Command prepP1Action;
    private final Command prepP2Action;
    private final Command prepP3Action;
    private final Command prepP4Action;
    private final Command prepP5Action;
    private final Command prepP6Action;

    private final Command shootFromPoseAction;
    private final Command reverseAction;
    private final Command shakeAction;
    private final Command testAction;

    private final VoltageSensor voltageSensor;

    private static final Set<ShooterStates> PREP_OR_SHOOT = EnumSet.of(
            ShooterStates.PREP_P1, ShooterStates.PREP_P2, ShooterStates.PREP_P3,
            ShooterStates.PREP_P4, ShooterStates.PREP_P5, ShooterStates.PREP_P6,
            ShooterStates.SHOOT_P1, ShooterStates.SHOOT_P2, ShooterStates.SHOOT_P3,
            ShooterStates.SHOOT_P4, ShooterStates.SHOOT_P5, ShooterStates.SHOOT_P6
    );
    /**
     * Creates a new ShooterSubsystem.
     * Initializes motors, servos, PIDs, and calculates preset values.
     */
    public ShooterSubsystem(HardwareMap hardwareMap , Supplier<Pose> poseSupplier) {
        this.poseSupplier = poseSupplier;

        leftMotor = hardwareMap.get(DcMotorEx.class, ShooterConstants.LeftMotorName);
        rightMotor = hardwareMap.get(DcMotorEx.class, ShooterConstants.RightMotorName);
        middleMotor = hardwareMap.get(DcMotorEx.class, ShooterConstants.MiddleMotorName);
        hoodServo = hardwareMap.get(Servo.class, ShooterConstants.HoodServoName);

        leftMotor.setDirection(ShooterConstants.LeftDirection);
        rightMotor.setDirection(ShooterConstants.RightDirection);
        middleMotor.setDirection(ShooterConstants.MiddleDirection);
        hoodServo.setDirection(ShooterConstants.HoodServoDirection);

        middleMotor.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
        middleMotor.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

        leftMotor.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
        leftMotor.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

        rightMotor.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
        rightMotor.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

        leftPID = new ShooterPIDFController(ShooterConstants.LeftPIDFCoefficients);
        middlePID = new ShooterPIDFController(ShooterConstants.MiddlePIDFCoefficients);
        rightPID = new ShooterPIDFController(ShooterConstants.RightPIDFCoefficients);

        leftPIDClose = new ShooterPIDFController(ShooterConstants.LeftPIDFCoefficientsClose);
        middlePIDClose = new ShooterPIDFController(ShooterConstants.MiddlePIDFCoefficientsClose);
        rightPIDClose = new ShooterPIDFController(ShooterConstants.RightPIDFCoefficientsClose);

        prevLRPM = 0;
        prevMRPM = 0;
        prevRRPM = 0;

        focusPoint = (Container.isBlue ? BluePositions.SHOOT_FOCUS_POINT : RedPositions.SHOOT_FOCUS_POINT);

        p1Pose = (Container.isBlue ? BluePositions.SHOOT_P1 : RedPositions.SHOOT_P1);
        p2Pose = (Container.isBlue ? BluePositions.SHOOT_P2 : RedPositions.SHOOT_P2);
        p3Pose = (Container.isBlue ? BluePositions.SHOOT_P3 : RedPositions.SHOOT_P3);
        p4Pose = (Container.isBlue ? BluePositions.SHOOT_P4 : RedPositions.SHOOT_P4);

        p1Rpm = calculateRpmFromPose(p1Pose);
        p2Rpm = calculateRpmFromPose(p2Pose);
        p3Rpm = calculateRpmFromPose(p3Pose);
        p4Rpm = calculateRpmFromPose(p4Pose);

        restRpm = ShooterConstants.RestRPM;

        p1Hood = calculateHoodFromPose(p1Pose);
        p2Hood = calculateHoodFromPose(p2Pose);
        p3Hood = calculateHoodFromPose(p3Pose);
        p4Hood = calculateHoodFromPose(p4Pose);

        prevROutput = 0;
        prevRPos = 0;
        prevMOutput = 0;
        prevMPos = 0;
        prevLOutput = 0;
        prevLPos = 0;
        prevLPosTime = 0;

        currentState = ShooterStates.ZERO;
        lastState = ShooterStates.ZERO;

        zeroAction = new ShooterZeroAction(this);
        restAction = new ShooterRestAction(this);
            shootP1Action = new ShooterShootP1Action(this);
            shootP2Action = new ShooterShootP2Action(this);
            shootP3Action = new ShooterShootP3Action(this);
            shootP4Action = new ShooterShootP4Action(this);
            shootP5Action = new ShooterShootP5Action(this);
        shootP6Action = new ShooterShootP6Action(this);

        prepP1Action = new ShooterPrepP1Action(this);
        prepP2Action = new ShooterPrepP2Action(this);
        prepP3Action = new ShooterPrepP3Action(this);
        prepP4Action = new ShooterPrepP4Action(this);
        prepP5Action = new ShooterPrepP5Action(this);
        prepP6Action = new ShooterPrepP6Action(this);

        shootFromPoseAction = new ShooterShootFromPoseAction(this);
        reverseAction = new ShooterReverseAction(this);
        shakeAction = new ShooterShakeAction(this);
        testAction = new ShooterTestAction(this);

        voltageSensor = hardwareMap.get(VoltageSensor.class,"Control Hub");
    }

    @Override
    public void periodic() {
        stateMachine();

        Container.shooterState = getState();
        /*leftPID.checkAndUpdateCoefficients(ShooterConstants.LeftPIDFCoefficients);
        middlePID.checkAndUpdateCoefficients(ShooterConstants.MiddlePIDFCoefficients);
        rightPID.checkAndUpdateCoefficients(ShooterConstants.RightPIDFCoefficients);*/
    }

    /**
     * Executes actions based on the current state of the shooter.
     */
    public void stateMachine() {
        switch (currentState) {
            case ZERO:
                if(!zeroAction.isScheduled()) zeroAction.schedule();
                break;
            case REST:
                if(!restAction.isScheduled()) restAction.schedule();
                break;
            // PREP States
            case PREP_P1:
                if(!prepP1Action.isScheduled()) prepP1Action.schedule();
                break;
            case PREP_P2:
                if(!prepP2Action.isScheduled()) prepP2Action.schedule();
                break;
            case PREP_P3:
                if(!prepP3Action.isScheduled()) prepP3Action.schedule();
                break;
            case PREP_P4:
                if(!prepP4Action.isScheduled()) prepP4Action.schedule();
                break;
            case PREP_P5:
                if(!prepP5Action.isScheduled()) prepP5Action.schedule();
                break;
            case PREP_P6:
                if(!prepP6Action.isScheduled()) prepP6Action.schedule();
                break;
            // SHOOT States
            case SHOOT_P1:
                if(!shootP1Action.isScheduled()) shootP1Action.schedule();
                break;
            case SHOOT_P2:
                if(!shootP2Action.isScheduled()) shootP2Action.schedule();
                break;
            case SHOOT_P3:
                if(!shootP3Action.isScheduled()) shootP3Action.schedule();
                break;
            case SHOOT_P4:
                if(!shootP4Action.isScheduled()) shootP4Action.schedule();
                break;
            case SHOOT_P5:
                if(!shootP5Action.isScheduled()) shootP5Action.schedule();
                break;
            case SHOOT_P6:
                if(!shootP6Action.isScheduled()) shootP6Action.schedule();
                break;
            case SHOOT_FROM_POSE:
                if(!shootFromPoseAction.isScheduled()) shootFromPoseAction.schedule();
                break;
            case REVERSE:
                if(!reverseAction.isScheduled()) reverseAction.schedule();
                break;
            case SHAKE:
                if(!shakeAction.isScheduled()) shakeAction.schedule();
                break;
            case TEST:
                if(!testAction.isScheduled()) testAction.schedule();
                break;
        }
    }

    /**
     * Requests a change in the shooter state.
     * @param requestedState The new state to request.
     */
    public void requestState(ShooterStates requestedState) {
        setState(requestedState);
    }

    /**
     * Sets the shooter state and updates the last state.
     * @param requestedState The new state.
     */
    public void setState(ShooterStates requestedState) {
        if(currentState != requestedState) lastState = currentState;
        currentState = requestedState;

    }

    /**
     * Gets the current state of the shooter.
     * @return The current ShooterStates.
     */
    public ShooterStates getState() {
        return currentState;
    }

    public Command zeroRequest() { return new ShooterZeroRequest(this); }
    public Command restRequest() { return new ShooterRestRequest(this); }
    public Command shootP1Request() { return new ShooterShootP1Request(this); }
    public Command shootP2Request() { return new ShooterShootP2Request(this); }
    public Command shootP3Request() { return new ShooterShootP3Request(this); }
    public Command shootP4Request() { return new ShooterShootP4Request(this); }
    public Command shootP5Request() { return new ShooterShootP5Request(this); }
    public Command shootP6Request() { return new ShooterShootP6Request(this); }


    public Command shootFromPoseRequest() { return new ShooterShootFromPoseRequest(this); }
    public Command reverseRequest() { return new ShooterReverseRequest(this); }
    public Command shakeRequest() { return new ShooterShakeRequest(this); }
    public Command testRequest() { return new ShooterTestRequest(this); }
    public Command prepP1Request() { return new ShooterPrepP1Request(this); }
    public Command prepP2Request() { return new ShooterPrepP2Request(this); }
    public Command prepP3Request() { return new ShooterPrepP3Request(this); }
    public Command prepP4Request() { return new ShooterPrepP4Request(this); }
    public Command prepP5Request() { return new ShooterPrepP5Request(this); }
    public Command prepP6Request() { return new ShooterPrepP6Request(this); }

    public void setCurrentState(ShooterStates currentState) {
        this.currentState = currentState;
    }

    private void setGoalRPM(double rpmGoal)
    {
        goalRPM = rpmGoal;
    }

    public double getGoalRPM() {
        return goalRPM;
    }

    private void setGoalHood(double hoodGoal)
    {
        goalHood = hoodGoal;
    }

    public double getGoalHood() {
        return goalHood;
    }


    private void setMotorPowers(double leftPower, double middlePower, double rightPower)
    {
        leftMotor.setPower(leftPower);
        middleMotor.setPower(middlePower);
        rightMotor.setPower(rightPower);

        prevLOutput = leftPower;
        prevMOutput = middlePower;
        prevROutput = rightPower;
    }

    private void setAllMotorPowers(double power)
    {
        setMotorPowers(power, power, power);
    }

    private void setHoodPosition(double position)
    {
        double goalPose = (Math.floor(position*ShooterConstants.HoodGearRatio/ShooterConstants.ServoAngleCapacity * 10000) / 10000.0);
        if ((goalPose<ShooterConstants.MaxHoodPosition)&&(goalPose>ShooterConstants.MinHoodPosition)) {
        setGoalHood(position);
        hoodServo.setPosition( //ShooterConstants.HoodStartTol -
                goalPose);}
    }

    public double getRightRPMRawT()
    {
        double currentP = rightMotor.getCurrentPosition();
        double now = System.currentTimeMillis();
        double rpm = (currentP - prevRPos) / (now - prevRPosTime) * 1000  / 8192;
        prevRPos = currentP;
        prevRPosTime = now;
        return rpm;
    }

    public double getRightRPMRaw()
    {
        return (rightMotor.getVelocity() * 60 / ShooterConstants.RightTicks);
    }

    public double getMiddleRPMRaw()
    {
        return (middleMotor.getVelocity() * 60 / ShooterConstants.MiddleTicks );
    }
    public double getLeftRPMRawT()
    {
        double currentP = leftMotor.getCurrentPosition();
        double now = System.currentTimeMillis();
        double deltaTime = (now - prevLPosTime) / 1000;
        double rpm = (((currentP - prevLPos)/deltaTime)/ShooterConstants.LeftTicks) * 60;
        prevLPos = currentP;
        prevLPosTime = now;
        return rpm;
    }

    public double getLeftRPMRaw()
    {
        //return getLeftRPMRawT();
        return (leftMotor.getVelocity() * 60 / 28);
        /*
        double rpm = (leftMotor.getCurrentPosition() - prevLPosTime);
        prevLPosTime = leftMotor.getCurrentPosition();
        return (leftMotor.getVelocity() * 60 / ShooterConstants.LeftTicks)*/
    }

    public double getRightRPM()
    {
        double rpm = prevRRPM*ShooterConstants.LastRpmCoefficient + getRightRPMRaw()*(1-ShooterConstants.LastRpmCoefficient);
        prevRRPM = getRightRPMRaw();

        return rpm;
    }

    public double getMiddleRPM()
    {
        double rpm = prevMRPM*ShooterConstants.LastRpmCoefficient + getMiddleRPMRaw()*(1-ShooterConstants.LastRpmCoefficient);
        prevMRPM = getMiddleRPMRaw();

        return rpm;
    }

    public double getLeftRPM()
    {
        double rpm = prevLRPM*ShooterConstants.LastRpmCoefficient + getLeftRPMRaw()*(1-ShooterConstants.LastRpmCoefficient);
        prevLRPM = getLeftRPMRaw();

        return rpm;
    }


    public double getHoodPosition()
    {
        return hoodServo.getPosition();
    }

    /**
     * Controls the motor RPM using PID controllers.
     * @param rpm The target RPM.
     */
    private void controlMotorRPM(double rpm)
    {
        if (PREP_OR_SHOOT.contains(currentState)) {
            leftPID.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
            middlePID.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
            rightPID.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
            leftPIDClose.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
            middlePIDClose.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
            rightPIDClose.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
        } else {
            leftPID.checkAndUpdateCoefficients(ShooterConstants.LeftPIDFCoefficients);
            middlePID.checkAndUpdateCoefficients(ShooterConstants.MiddlePIDFCoefficients);
            rightPID.checkAndUpdateCoefficients(ShooterConstants.RightPIDFCoefficients);
            leftPIDClose.checkAndUpdateCoefficients(ShooterConstants.LeftPIDFCoefficientsClose);
            middlePIDClose.checkAndUpdateCoefficients(ShooterConstants.MiddlePIDFCoefficientsClose);
            rightPIDClose.checkAndUpdateCoefficients(ShooterConstants.RightPIDFCoefficientsClose);
        }
        /*
        leftPID.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
        middlePID.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
        rightPID.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
        leftPIDClose.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
        middlePIDClose.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());
        rightPIDClose.doVoltageCompensation(ShooterConstants.calibratedVoltage,voltageSensor.getVoltage());*/
        setGoalRPM(rpm);

        double leftRPM = getLeftRPM();
        double middleRPM = getMiddleRPM();
        double rightRPM = getRightRPM();

        double leftGoal = goalRPM*ShooterConstants.MultiplierLeft;
        double middleGoal = goalRPM*ShooterConstants.MultiplierMiddle;
        double rightGoal = goalRPM*ShooterConstants.MultiplierRight;

        double diffLeft = Math.abs(leftGoal - leftRPM);
        double diffMiddle = Math.abs(middleGoal - middleRPM);
        double diffRight = Math.abs(rightGoal - rightRPM);

        double pidLOutput = leftPID.calculate(leftRPM, leftGoal);
        if(diffLeft<ShooterConstants.CloseRPMTolerance) pidLOutput = leftPIDClose.calculate(leftRPM,leftGoal);
        double lOutput = MathUtils.clamp(prevLOutput + pidLOutput, -0.6, 1);

        double pidMOutput = middlePID.calculate(middleRPM, middleGoal);
        if(diffMiddle<ShooterConstants.CloseRPMTolerance) pidMOutput = middlePIDClose.calculate(middleRPM,middleGoal);
        double mOutput = MathUtils.clamp(prevMOutput + pidMOutput, -0.6, 1);

        double pidROutput = rightPID.calculate(rightRPM, rightGoal);
        if(diffRight<ShooterConstants.CloseRPMTolerance) pidROutput = rightPIDClose.calculate(rightRPM,rightGoal);
        double rOutput = MathUtils.clamp(prevROutput + pidROutput, -0.6, 1);

        setMotorPowers(lOutput, mOutput,  rOutput);
    }

    /**
     * Checks if the current RPM is within tolerance of the goal.
     * @param RPM The target RPM.
     * @return True if within tolerance.
     */
    public boolean checkRPMRaw(double RPM) {
        double lGoal = RPM * ShooterConstants.MultiplierLeft;
        double mGoal = RPM * ShooterConstants.MultiplierMiddle;
        double rGoal = RPM * ShooterConstants.MultiplierRight;

        return checkSingleMotorTol(getLeftRPM(), lGoal) &&
                checkSingleMotorTol(getMiddleRPM(), mGoal) &&
                checkSingleMotorTol(getRightRPM(), rGoal);
    }

    /**
     * Helper method to check if a motor is within the asymmetrical tolerance window.
     * Formula: (Goal - LowTol) <= Current <= (Goal + HighTol)
     */
    private boolean checkSingleMotorTol(double currentRPM, double goalRPM) {
        if (Container.isTeleop){
        return (currentRPM >= (goalRPM - ShooterConstants.RpmTolLow)) &&
                (currentRPM <= (goalRPM + ShooterConstants.RpmTol));}
        else {
        return (currentRPM >= (goalRPM - ShooterConstants.RpmTolLowAuto)) &&
                (currentRPM <= (goalRPM + ShooterConstants.RpmTol));}
    }

    public boolean checkRPMRawLeft(double goalRPM) {
        double lGoal = goalRPM * ShooterConstants.MultiplierLeft;
        return checkSingleMotorTol(getLeftRPM(), lGoal);
    }

    public boolean checkRPMRawRight(double goalRPM) {
        double rGoal = goalRPM * ShooterConstants.MultiplierRight;
        return checkSingleMotorTol(getRightRPM(), rGoal);
    }

    public boolean checkRPMRawMiddle(double goalRPM) {
        double mGoal = goalRPM * ShooterConstants.MultiplierMiddle;
        return checkSingleMotorTol(getMiddleRPM(), mGoal);
    }

    public boolean checkRPM(double RPM) {
        boolean lastChecked = checkedRPMOnce;
        checkedRPMOnce = checkRPMRaw(RPM);

        // Returns true only if it was in range last loop AND this loop (debounce)
        return lastChecked && checkedRPMOnce;
    }


    /**
     * Checks if the hood is within tolerance of the goal position.
     * @param hood The target hood position.
     * @return True if within tolerance.
     */
    public boolean checkHood(double hood)
    {

        return (Math.abs(hood - getHoodPosition()) < ShooterConstants.HoodTol);
    }

    private double calculateRpmFromPose(@NonNull Pose p)
    {
        double robotY = p.getY();
        double robotX = p.getX();

        double distance = Math.sqrt(Math.pow(focusPoint.getX()-robotX,2) + Math.pow(focusPoint.getY()-robotY,2))*2.54;

        return ShooterConstants.CalculateRpmFromDistance(distance);
    }

    private double calculateHoodFromPose(@NonNull Pose p)
    {
        double robotY = p.getY();
        double robotX = p.getX();

        double distance = Math.sqrt(Math.pow(focusPoint.getX()-robotX,2) + Math.pow(focusPoint.getY()-robotY,2))*2.54;

        return  ShooterConstants.CalculateHoodFromDistance(distance);
    }

    private double calculateRpmFromCurrentPose()
    {
        Pose botPose = poseSupplier.get();
        double robotY = botPose.getY();
        double robotX = botPose.getX();
        double distance = Math.sqrt(Math.pow(focusPoint.getX()-robotX,2) + Math.pow(focusPoint.getY()-robotY,2))*2.54;
        return ShooterConstants.hoodInterpolator(distance);
    }

    private double calculateHoodFromCurrentPose()
    {
        Pose botPose = poseSupplier.get();
        double robotY = botPose.getY();
        double robotX = botPose.getX();
        double distance = Math.sqrt(Math.pow(focusPoint.getX()-robotX,2) + Math.pow(focusPoint.getY()-robotY,2))*2.54;
        return ShooterConstants.hoodInterpolator(distance);
    }

    public boolean isReady()
    {
        return isReady;
    }

    private void setIsReady(boolean ready)
    {
        isReady = ready;
    }

    private void setIsReadyByChecking()
    {
        setIsReady(checkRPM(goalRPM));
    }

    public void zero()
    {
        setAllMotorPowers(0);
        setGoalRPM(0);

        //setHoodPosition(ShooterConstants.TestHoodPos);
        setHoodPosition(30);

        setIsReady(true);
    }

    public void rest()
    {

        Pose goalPositionrest = (Container.isBlue ? BluePositions.SHOOT_P5 : RedPositions.SHOOT_P5);
        double distancerest = Math.sqrt(Math.pow(goalPositionrest.getX()-poseSupplier.get().getX(),2) + Math.pow(goalPositionrest.getY()-poseSupplier.get().getY(),2));
        setHoodPosition(ShooterConstants.hoodInterpolator(distancerest));
        if (Container.isTeleop) {
            Pose botPose = poseSupplier.get();

            Pose focus = (Container.isBlue ? BluePositions.FOCUS_POINT : RedPositions.FOCUS_POINT);
            if (Container.isBlue) focus = focus.withY(focus.getY()- ShooterConstants.getBlueFocusPointOffset(botPose.getHeading()));
            else  focus = focus.withY(focus.getY()- ShooterConstants.getRedFocusPointOffset(botPose.getHeading()));

            double distance = Math.sqrt(Math.pow(focus.getX()-botPose.getX(),2) + Math.pow(focus.getY()-botPose.getY(),2));
            restRpm = ShooterConstants.rpmInterpolator(distance)-ShooterConstants.restRPMOffset;
            if (restRpm<ShooterConstants.RestRPM) {
                restRpm = ShooterConstants.RestRPM;
            }
        }
        if(!Container.isTeleop) {
            if(!Container.farShootAuto)
            controlMotorRPM(ShooterConstants.rpmInterpolator(distancerest)+50);
            else {
                Pose goalPositionrestfar = (Container.isBlue ? BluePositions.SHOOT_P5 : RedPositions.SHOOT_P5);
                double distancerestfar = Math.sqrt(Math.pow(goalPositionrestfar.getX()-poseSupplier.get().getX(),2) + Math.pow(goalPositionrestfar.getY()-poseSupplier.get().getY(),2));
                controlMotorRPM(ShooterConstants.rpmInterpolator(distancerestfar)+125);
            }

        }
        else controlMotorRPM(restRpm);

    }

    // Generalized method to reduce boilerplate
    private void shoot(double rpm, double hoodPos) {
        setIsReadyByChecking();
        setHoodPosition(hoodPos);
        controlMotorRPM(rpm);
    }

    // Position Methods
    public void shootP1() { shoot(ShooterConstants.P1Rpm, ShooterConstants.P1HoodPos); }
    public void shootP2() { shoot(ShooterConstants.P2Rpm, ShooterConstants.P2HoodPos); }
    public void shootP3() { shoot(ShooterConstants.P3Rpm, ShooterConstants.P3HoodPos); }
    public void shootP4() { shoot(ShooterConstants.P4Rpm, ShooterConstants.P4HoodPos); }
    public void shootP5() { shoot(ShooterConstants.P5Rpm, ShooterConstants.P5HoodPos); }
    public void shootP6() {
        Pose goalPosition = (Container.isBlue ? BluePositions.SHOOT_P6 : RedPositions.SHOOT_P6);
        double distance = Math.sqrt(Math.pow(goalPosition.getX()-poseSupplier.get().getX(),2) + Math.pow(goalPosition.getY()-poseSupplier.get().getY(),2));
        shoot(ShooterConstants.rpmInterpolator(distance),ShooterConstants.hoodInterpolator(distance));
    }

    // Prep Methods
    // Note: Prep usually doesn't change hood position to save servo wear,
    // or it moves it to a safe middle ground.
    /**
     * Helper method to calculate RPM based on a target Pose.
     * Uses the Euclidean distance formula: d = sqrt((x2-x1)^2 + (y2-y1)^2)
     */
    private void prepareDynamicShot(Pose goalPosition) {

        Pose focus = (Container.isBlue ? BluePositions.FOCUS_POINT : RedPositions.FOCUS_POINT);
        if (Container.isBlue) focus = focus.withY(focus.getY()- ShooterConstants.getBlueFocusPointOffset(goalPosition.getHeading()));
        else  focus = focus.withY(focus.getY()- ShooterConstants.getRedFocusPointOffset(goalPosition.getHeading()));

        double distance = Math.sqrt(Math.pow(focus.getX()-goalPosition.getX(),2) + Math.pow(focus.getY()-goalPosition.getY(),2));

        // Applying the interpolator with your +500 RPM buffer
        controlMotorRPM(ShooterConstants.rpmInterpolator(distance) + ShooterConstants.prepRPMOffset);
        setHoodPosition(ShooterConstants.hoodInterpolator(distance));
    }

    private void prepareDynamicShotWithOffset(Pose goalPosition,double rpmOffset) {

        Pose focus = (Container.isBlue ? BluePositions.FOCUS_POINT : RedPositions.FOCUS_POINT);
        if (Container.isBlue) focus = focus.withY(focus.getY()- ShooterConstants.getBlueFocusPointOffset(goalPosition.getHeading()));
        else  focus = focus.withY(focus.getY()- ShooterConstants.getRedFocusPointOffset(goalPosition.getHeading()));

        double distance = Math.sqrt(Math.pow(focus.getX()-goalPosition.getX(),2) + Math.pow(focus.getY()-goalPosition.getY(),2));

        // Applying the interpolator with your +500 RPM buffer
        controlMotorRPM(ShooterConstants.rpmInterpolator(distance) + rpmOffset);
        setHoodPosition(ShooterConstants.hoodInterpolator(distance));
    }



    public void prepP1() {
        Pose pose = (Container.isBlue ? BluePositions.SHOOT_P1 : RedPositions.SHOOT_P1);
        prepareDynamicShot(pose);
    }

    public void prepP2() {
        prepareDynamicShot(Container.isBlue ? BluePositions.SHOOT_P2 : RedPositions.SHOOT_P2);
    }

    public void prepP3() {
        prepareDynamicShot(Container.isBlue ? BluePositions.SHOOT_P3 : RedPositions.SHOOT_P3);
    }

    public void prepP4() {
        prepareDynamicShot(Container.isBlue ? BluePositions.SHOOT_P4 : RedPositions.SHOOT_P4);
    }

    public void prepP5() {
        if (!Container.autoPrep1) prepareDynamicShot(Container.isBlue ? BluePositions.SHOOT_P5 : RedPositions.SHOOT_P5);
        else prepareDynamicShotWithOffset(Container.isBlue ? BluePositions.SHOOT_P5 : RedPositions.SHOOT_P5, ShooterConstants.prepRPMOffsetAuto1);
    }

    public void prepP6() {
        prepareDynamicShot(Container.isBlue ? BluePositions.SHOOT_P6 : RedPositions.SHOOT_P6);
    }


    public void shootFromPose()
    {
        Pose botPose = poseSupplier.get();
        double robotY = botPose.getY();
        double robotX = botPose.getX();
        double distance = Math.sqrt(Math.pow(focusPoint.getX()-robotX,2) + Math.pow(focusPoint.getY()-robotY,2));
        setHoodPosition(ShooterConstants.hoodInterpolator(distance));
        controlMotorRPM(ShooterConstants.rpmInterpolator(distance));
        setIsReadyByChecking();
    }


    public void reverse()
    {
        setAllMotorPowers(-0.3);
        setGoalRPM(-1);

        setHoodPosition(0.01);

        setIsReady(true);
    }

    public void shake()
    {
        setAllMotorPowers(0);
        setGoalRPM(0);

        setHoodPosition(0);

        setIsReady(true);
    }

    public void test()
    {
        setIsReadyByChecking();
        setHoodPosition(ShooterConstants.TestHoodPos);
        controlMotorRPM(ShooterConstants.TestRpm);
    }

    public void zeroHood()
    {
        setHoodPosition(0);
    }

    public Command waitForReady()
    {
        return new WaitUntilCommand(this::isReady);
    }
    public VoltageSensor getVoltageSensor() { return voltageSensor; }
}
