package org.firstinspires.ftc.teamcode.Utils;

import com.arcrobotics.ftclib.controller.PIDController;
import com.arcrobotics.ftclib.controller.PIDFController;
import com.qualcomm.robotcore.hardware.PIDCoefficients;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.teamcode.Container;
import org.firstinspires.ftc.teamcode.Subsystems.ShooterSubsystem;

/**
 * Custom PID controller wrapper for the shooter.
 * Extends the FTCLib PIDController.
 */
public class ShooterPIDFController extends PIDFController
{
    /**
     * Creates a new ShooterPIDController using PIDCoefficients.
     * @param pidfCoefficients The PID coefficients (p, i, d).
     */
    PIDFCoefficients pidfCoefficientsFIRST;
    public ShooterPIDFController(PIDFCoefficients pidfCoefficients) {
        super(pidfCoefficients.p, pidfCoefficients.i, pidfCoefficients.d,pidfCoefficients.f);
        pidfCoefficientsFIRST = pidfCoefficients;
    }

    public void setPidfCoefficients(PIDFCoefficients pidfCoefficients)
    {
        setPIDF(pidfCoefficients.p, pidfCoefficients.i, pidfCoefficients.d, pidfCoefficients.f);
    }

    public PIDFCoefficients getPidfCoefficients()
    {
        return new PIDFCoefficients(getP(), getI(), getD(), getF());
    }

    public void  checkAndUpdateCoefficients(PIDFCoefficients pidfCoefficients)
    {
        if (pidfCoefficients.p != getP() || pidfCoefficients.i != getI() || pidfCoefficients.d != getF() || pidfCoefficients.f != getF()) setPidfCoefficients(pidfCoefficients);
    }

    public void doVoltageCompensation(double calibratedVoltage, double voltage){
        //if (Container.isTeleop) {
        double percentage = calibratedVoltage/voltage;
        PIDFCoefficients newPID = new PIDFCoefficients(getP()*percentage,getI()*percentage,getD()*percentage,getF()*percentage);
        checkAndUpdateCoefficients(newPID); //} else
            //checkAndUpdateCoefficients(pidfCoefficientsFIRST);
    }
}
