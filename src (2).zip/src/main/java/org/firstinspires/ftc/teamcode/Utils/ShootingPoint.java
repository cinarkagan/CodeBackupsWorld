package org.firstinspires.ftc.teamcode.Utils;

public class ShootingPoint {
    public double distance;
    public double rpm;
    public double hood;

    public ShootingPoint(double distance, double rpm, double hood) {
        this.distance = distance;
        this.rpm = rpm;
        this.hood = hood;
    }
}
