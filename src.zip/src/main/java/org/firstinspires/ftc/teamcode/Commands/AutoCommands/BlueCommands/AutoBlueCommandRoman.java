package org.firstinspires.ftc.teamcode.Commands.AutoCommands.BlueCommands;

import com.arcrobotics.ftclib.command.Command;
import com.arcrobotics.ftclib.command.InstantCommand;
import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.arcrobotics.ftclib.command.WaitCommand;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;

import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.DriveToShootP5;
import org.firstinspires.ftc.teamcode.Commands.DrivetrainCommands.FollowPathAuto;
import org.firstinspires.ftc.teamcode.Constants.DrivetrainConstants;
import org.firstinspires.ftc.teamcode.Container;
import org.firstinspires.ftc.teamcode.Subsystems.DrivetrainSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.TheMachineSubsystem;

public class AutoBlueCommandRoman extends SequentialCommandGroup {
    private final TheMachineSubsystem m_machine;
    private final DrivetrainSubsystem m_drive;

    private Command driveAndShootP5_1;
    private Command driveAndShootP5_2;
    private Command driveAndShootP5_3;
    private Command driveAndShootP1_4;

    public AutoBlueCommandRoman(TheMachineSubsystem theMachineSubsystem, DrivetrainSubsystem drivetrain) {
        this.m_machine = theMachineSubsystem;
        this.m_drive = drivetrain;

        AutoBlueCommandRoman.Paths paths = new AutoBlueCommandRoman.Paths(drivetrain.getFollower());


        driveAndShootP5_1 = new DriveToShootP5(drivetrain).alongWith(m_machine.prepP5Request()).withTimeout(DrivetrainConstants.AimTimeOut*2)
                .andThen(m_machine
                        .shootFromPoseRequest());
        driveAndShootP5_2 = new DriveToShootP5(drivetrain).alongWith(m_machine.prepP5Request()).withTimeout(DrivetrainConstants.AimTimeOut)
                .andThen(m_machine
                        .shootFromPoseRequest());
        driveAndShootP5_3 = new DriveToShootP5(drivetrain).alongWith(m_machine.prepP5Request()).withTimeout(DrivetrainConstants.AimTimeOut)
                .andThen(m_machine.shootFromPoseRequest());
        addCommands(
                new InstantCommand(()->{
                    Container.autoPrep1 = true;
                }),
                driveAndShootP5_1,
                theMachineSubsystem.waitForFeederToFeed(),
                new InstantCommand(()->{
                    Container.autoPrep1 = false;
                }),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(drivetrain,paths.Intake1),
                new WaitCommand(250),
                driveAndShootP5_2,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(m_drive, paths.IntakeLever),
                new WaitCommand(800),
                m_machine.prepP5Request(),
                new FollowPathAuto(m_drive,paths.ReturnShoot1),
                driveAndShootP5_2,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(m_drive, paths.IntakeLever),
                new WaitCommand(800),
                m_machine.prepP5Request(),
                new FollowPathAuto(m_drive,paths.ReturnShoot1),
                driveAndShootP5_2,
                theMachineSubsystem.waitForFeederToFeed(),
                theMachineSubsystem.intakeRequest(),
                new FollowPathAuto(m_drive, paths.IntakeLever),
                new WaitCommand(800),
                m_machine.prepP5Request(),
                new FollowPathAuto(m_drive,paths.ReturnShoot1),
                driveAndShootP5_2
        );
    }

    public static class Paths {
        public PathChain Intake1;
        public PathChain IntakeLever;
        public PathChain ReturnShoot1;

        public Paths(Follower follower) {
            Intake1 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    new Pose(54.800, 82.000),
                                    new Pose(49.509, 91.019),
                                    new Pose(20.226, 56.453)
                            )
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(130), Math.toRadians(30))
                    .build();

            IntakeLever = follower.pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    new Pose(54.613, 82.000),
                                    new Pose(38.910, 33.735),
                                    new Pose(12, 62.2)
                            )
                    )
                    .setTangentHeadingInterpolation()
                    .setReversed()
                    .build();
            ReturnShoot1 = follower.pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    new Pose(12, 62.2),
                                    new Pose(38.910, 33.735),
                                    new Pose(54.613, 82.000)
                            )
                    )
                    .setTangentHeadingInterpolation()
                    .build();
        }
    }
}
