package org.firstinspires.ftc.teamcode.Commands.AutoCommands.UtilCommands;

import com.arcrobotics.ftclib.command.SequentialCommandGroup;
import com.arcrobotics.ftclib.command.WaitCommand;

import org.firstinspires.ftc.teamcode.Subsystems.DrivetrainSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.TheMachineSubsystem;

public class FitFitCommand extends SequentialCommandGroup {
    private final TheMachineSubsystem theMachineSubsystem;
    private final DrivetrainSubsystem drivetrain;
    public FitFitCommand(TheMachineSubsystem theMachineSubsystem, DrivetrainSubsystem drivetrain) {
        this.theMachineSubsystem = theMachineSubsystem;
        this.drivetrain = drivetrain;
        addCommands(
                theMachineSubsystem.getIntakeSubsystem().intakeRequest(),
                new WaitCommand(100),
                theMachineSubsystem.getIntakeSubsystem().outtakeRequest(),
                new WaitCommand(100),
                theMachineSubsystem.getIntakeSubsystem().intakeRequest(),
                new WaitCommand(100),
                theMachineSubsystem.getIntakeSubsystem().outtakeRequest()
        );
    }
}
