package org.firstinspires.ftc.teamcode.Utils;

import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.telemetry;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.Constants.DrivetrainConstants;
import org.firstinspires.ftc.teamcode.Constants.ShooterConstants;
import org.firstinspires.ftc.teamcode.Constants.TheMachineConstants;
import org.firstinspires.ftc.teamcode.Container;
import org.firstinspires.ftc.teamcode.Positions.BluePositions;
import org.firstinspires.ftc.teamcode.Subsystems.DrivetrainSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.FunnelSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.IntakeSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.ShooterSubsystem;
import org.firstinspires.ftc.teamcode.Subsystems.TheMachineSubsystem;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.arcrobotics.ftclib.command.CommandScheduler;
import com.bylazar.telemetry.PanelsTelemetry;
import com.bylazar.telemetry.JoinedTelemetry;
import com.bylazar.telemetry.TelemetryManager;
import com.pedropathing.geometry.Pose;
import com.qualcomm.robotcore.hardware.VoltageSensor;


public class Mouth {

    private final TheMachineSubsystem machineSubsystem;
    private final DrivetrainSubsystem drivetrainSubsystem;
    private final IntakeSubsystem intakeSubsystem;
    private final FunnelSubsystem funnelSubsystem;
    private final ShooterSubsystem shooterSubsystem;
    private final LimelightHandler llHandler;

    private final TelemetryManager.TelemetryWrapper panelsTelemetry;
    private final JoinedTelemetry joinedTelemetry;

    //private final VoltageSensor voltSensor;

    private final CommandScheduler scheduler;

    public Mouth(TheMachineSubsystem machineSubsystem, DrivetrainSubsystem drivetrainSubsystem, Telemetry telemetry)
    {
        this.machineSubsystem = machineSubsystem;
        this.drivetrainSubsystem = drivetrainSubsystem;
        this.intakeSubsystem = machineSubsystem.getIntakeSubsystem();
        this.funnelSubsystem = machineSubsystem.getFunnelSubsystem();
        this.shooterSubsystem = machineSubsystem.getShooterSubsystem();
        this.llHandler = machineSubsystem.getLimelightHandler();
        PanelsFieldDrawing.init();
        telemetry = new MultipleTelemetry(FtcDashboard.getInstance().getTelemetry(),telemetry);
        panelsTelemetry = PanelsTelemetry.INSTANCE.getFtcTelemetry();
        joinedTelemetry = new JoinedTelemetry(panelsTelemetry, telemetry);

        scheduler = CommandScheduler.getInstance();
    }

    public void speak()
    {
        // DriveTrain
        PanelsFieldDrawing.drawRobot(drivetrainSubsystem.getPose());
        PanelsFieldDrawing.sendPacket();
        joinedTelemetry.addData("Drive-State", drivetrainSubsystem.getState());

        if (Container.ShouldIShout)       {
            joinedTelemetry.addData("Robot-X", drivetrainSubsystem.getPose().getX());
            joinedTelemetry.addData("Robot-Y", drivetrainSubsystem.getPose().getY());
            joinedTelemetry.addData("Robot-H", drivetrainSubsystem.getPose().getHeading());

            joinedTelemetry.addData("ERROR-PID-X", drivetrainSubsystem.getXErrorPID());
            joinedTelemetry.addData("ERROR-PID-Y", drivetrainSubsystem.getYErrorPID());
            joinedTelemetry.addData("ERROR-PID-H", drivetrainSubsystem.getHeadingErrorPID());

            joinedTelemetry.addData("Shooter-RPM-Goal", shooterSubsystem.getGoalRPM());
            joinedTelemetry.addData("Shooter-RPM-Left", shooterSubsystem.getLeftRPM());
            joinedTelemetry.addData("Shooter-RPM-Middle", shooterSubsystem.getMiddleRPM());
            joinedTelemetry.addData("Shooter-RPM-Right", shooterSubsystem.getRightRPM());
            joinedTelemetry.addData("Shooter-HOOD-Goal", shooterSubsystem.getGoalHood());
            joinedTelemetry.addData("Shooter-HOOD-Current", shooterSubsystem.getHoodPosition());

            Pose botPose = machineSubsystem.getLLPoseMT();

            joinedTelemetry.addData("Bot-X", botPose.getX());
            joinedTelemetry.addData("Bot-Y",  botPose.getY());
            joinedTelemetry.addData("Bot-H", botPose.getHeading());

        }
        Pose botPose = drivetrainSubsystem.getPose();
        joinedTelemetry.addData("Bot-X", botPose.getX());
        joinedTelemetry.addData("Bot-Y",  botPose.getY());
        joinedTelemetry.addData("Bot-H", botPose.getHeading());

        joinedTelemetry.addData("Hood pos", machineSubsystem.getShooterSubsystem().getHoodPosition());
        joinedTelemetry.addData("Goal RPM", machineSubsystem.getShooterSubsystem().getGoalRPM());
        joinedTelemetry.addData("RPM", machineSubsystem.getShooterSubsystem().getMiddleRPM());

        joinedTelemetry.addData("Voltage",shooterSubsystem.getVoltageSensor().getVoltage());
        //joinedTelemetry.addData("Drive-IsBusy", drivetrainSubsystem.isBusy());

        //panelsTelemetry.addData("Drive-Pose-X", drivetrainSubsystem.getPose().getX());
        //panelsTelemetry.addData("Drive-Pose-Y", drivetrainSubsystem.getPose().getY());
        //panelsTelemetry.addData("Drive-Pose-Heading", drivetrainSubsystem.getPose().getHeading());
        //panelsTelemetry.addData("Drive-Error-Heading", drivetrainSubsystem.getHeadingError());
        //panelsTelemetry.addData("Drive-Error-Drive", drivetrainSubsystem.getDriveError());
        //panelsTelemetry.addData("Drive-Error-Translational", drivetrainSubsystem.getTranslationalError());
        //panelsTelemetry.addData("Drive-IsBusy", drivetrainSubsystem.isBusy());
        //panelsTelemetry.addData("Drive-AtPose-P1", drivetrainSubsystem.atPose(BluePositions.SHOOT_P1));
        //panelsTelemetry.addData("Drive-AtPose-P2", drivetrainSubsystem.atPose(BluePositions.SHOOT_P2));
        //panelsTelemetry.addData("Drive-AtPose-P3", drivetrainSubsystem.atPose(BluePositions.SHOOT_P3));
        //panelsTelemetry.addData("Drive-AtPose-P4", drivetrainSubsystem.atPose(BluePositions.SHOOT_P4));


        // Intake
        joinedTelemetry.addData("Intake-State", intakeSubsystem.getState());

        // Shooter
        joinedTelemetry.addData("Shooter-State", shooterSubsystem.getState());
        //joinedTelemetry.addData("Shooter-IsReady", shooterSubsystem.isReady());

        //joinedTelemetry.addData("Shooter-RPM-Goal", shooterSubsystem.getGoalRPM());
        //joinedTelemetry.addData("Shooter-RPM-Left", shooterSubsystem.getLeftRPM());
        //joinedTelemetry.addData("Shooter-RPM-Middle", shooterSubsystem.getMiddleRPM());
        //joinedTelemetry.addData("Shooter-RPM-Right", shooterSubsystem.getRightRPM());
        //panelsTelemetry.addData("Shooter-HOOD-Goal", shooterSubsystem.getGoalHood());
        //panelsTelemetry.addData("Shooter-HOOD-Current", shooterSubsystem.getHoodPosition());
        //panelsTelemetry.addData("Shooter-IsReady", shooterSubsystem.isReady());

        // Funnel
        joinedTelemetry.addData("Funnel-State", funnelSubsystem.getState());
        //joinedTelemetry.addData("Funnel-IsFull", funnelSubsystem.isFull());
        //String fComb = funnelSubsystem.getFunnelFeedOrder()[0] + " " + funnelSubsystem.getFunnelFeedOrder()[1] + " " + funnelSubsystem.getFunnelFeedOrder()[2];
        //joinedTelemetry.addData("FeedCombination", fComb);

        //String gComb = funnelSubsystem.getFunnelGreenRatioOrder()[0] + " " + funnelSubsystem.getFunnelGreenRatioOrder()[1] + " " + funnelSubsystem.getFunnelGreenRatioOrder()[2];
        //joinedTelemetry.addData("GreenCombination", gComb);

        joinedTelemetry.addData("ColorCombination", Container.colorCombination);

        //joinedTelemetry.addData("SensorL", funnelSubsystem.getSensorL().getNormalizedColors().toColor());
        //joinedTelemetry.addData("SensorM", funnelSubsystem.getSensorM().getNormalizedColors().toColor());
        //joinedTelemetry.addData("SensorR", funnelSubsystem.getSensorR().getNormalizedColors().toColor());

        //panelsTelemetry.addData("Funnel-IsReady", funnelSubsystem.isReady());

        // Limelight

        //joinedTelemetry.addData("Limelight-BotPose", llHandler.getPose().toString());
        //joinedTelemetry.addData("Limelight-BotPosePedro", llHandler.getPosePedro().toString());
        //joinedTelemetry.addData("Limelight-BotPosePedro-x", llHandler.getPosePedro().getX());
        //joinedTelemetry.addData("Limelight-BotPosePedro-y", llHandler.getPosePedro().getY());
        //joinedTelemetry.addData("Limelight-BotPosePedro-theta", Math.toRadians(llHandler.getPosePedro().getHeading()));

        // Machine
        joinedTelemetry.addData("Machine-State", machineSubsystem.getState());

        //panelsTelemetry.addData("Machine-IsReady", machineSubsystem.isReady());

        // Command Scheduler
        //panelsTelemetry.addData("CommandScheduler", scheduler);


        joinedTelemetry.update();
    }
    public JoinedTelemetry getJoinedTelemetry() {
        return joinedTelemetry;
    }
}
